#include <kern/types.h>
#include <lib.h>
#include <kern/errno.h>
#include <array.h>
#include <machine/spl.h>
#include <machine/pcb.h>
#include <process.h>
#include <thread.h>
#include <curthread.h>
#include <synch.h>

/* Array of NULL processes */
static struct process *process_table[MAX_PROCESSES+1];

/* Process table Initialization */
void process_bootstrap(void){
	int i;
	for(i = 1;i < MAX_PROCESSES+1;i++){
		process_table[i] = NULL;
	}
}

/* Allocate memory for items within process table using thread *tf */
pid_t pid_allocate(struct thread *th){
	int i = 0;
	pid_t pid = -1;
	
	/* Get new pid number not in use */
	for(i = 1;i < MAX_PROCESSES+1;i++){
		if(process_table[i] == NULL){
			break;
		}
	}
	
	if(i <= MAX_PROCESSES){
		pid = i;
		char name[16];
		process_table[i] = kmalloc(sizeof(struct process));
		process_table[i]->exit_status = 0;
		process_table[i]->exit = 0;
		process_table[i]->pPid = -1;
		snprintf(name, sizeof(name), "lock thread: %d", pid);
		process_table[i]->exitlock = lock_create(name);
		process_table[i]->self = kmalloc(sizeof(struct thread));
		memcpy(process_table[i]->self, th, sizeof(struct thread));
		process_table[i]->pid = (pid_t)pid;
	}
	
	return pid;
}

/* To check if the pid given is currently in table */
int p_exists(pid_t pid){
	if(pid >= 1 && pid <= MAX_PROCESSES && process_table[pid] != NULL){
		return 1;
	}
	else{
		return 0;
	}
}

/* Remove the process from the table to free up pid */
int remove_process(pid_t pid){
	if(!p_exists(pid)){
		return -1;
	}
	
	lock_destroy(process_table[pid]->exitlock);

	kfree(process_table[pid]->self);
	kfree(process_table[pid]);
	process_table[pid] = NULL;
	return 0;
}

/* Get process struct from table using the pid number */
struct process* get_process(pid_t pid){
	return process_table[pid];
}
