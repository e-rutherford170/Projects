/*
 * Get process id of parent process
 */

#include <thread.h>
#include <curthread.h>
#include <kern/types.h>
#include <syscall.h>
#include <process.h>

pid_t sys_getppid() {
	
	pid_t pid = curthread->pid;
	struct process *child = get_process(pid);

	if (child != NULL) {
		if(child->pPid == -1){
			return -1;
		}
		return child->pPid;
	}

	return -1;
}
