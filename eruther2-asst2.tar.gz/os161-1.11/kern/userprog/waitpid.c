#include <types.h>
#include <kern/types.h>
#include <lib.h>
#include <kern/errno.h>
#include <thread.h>
#include <curthread.h>
#include <synch.h>
#include <process.h>

int sys_waitpid(pid_t pid, userptr_t status, int options, int *retval){
	
	(void) options;
	int result, stat;
	struct process *p = get_process(pid);
	if(p == NULL){
		*retval = -1;
		return EINVAL;
	}
	
	// Acquire the process lock
	lock_acquire(p->exitlock);
	pid_t cur_pid = curthread->pid;
	
	// Copy user status using copyin
	result = copyin((userptr_t)status, &stat, sizeof(status));
	
	if(result && p->pPid != -1){
		lock_release(p->exitlock);
		*retval = -1;
		return result;
	}
	
	if(!p_exists(pid) || pid <= cur_pid){
		lock_release(p->exitlock);
		*retval = -1;
		return EINVAL;
	}

	if(status == NULL){
		lock_release(p->exitlock);
		*retval = -1;
		return EINVAL;
	}

	if(options > 0){
		*retval = -1;
		lock_release(p->exitlock);
		return EINVAL;
	}
	
	p->exit_status = (int)status;
	*retval = pid;

	lock_release(p->exitlock);

	// Free pid from process table
	remove_process(pid);
	return 0;
}
