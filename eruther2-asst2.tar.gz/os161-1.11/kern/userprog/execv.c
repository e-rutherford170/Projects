/*
 * Sample/test code for running a user program.  You can use this for
 * reference when implementing the execv() system call. Remember though
 * that execv() needs to do more than this function does.
 */

#include <types.h>
#include <kern/unistd.h>
#include <kern/errno.h>
#include <lib.h>
#include <addrspace.h>
#include <thread.h>
#include <curthread.h>
#include <vm.h>
#include <vfs.h>
#include <test.h>

/*
 * Load program "progname" and start running it in usermode.
 * Does not return except on error.
 *
 * Calls vfs_open on progname and thus may destroy it.
 */

int sys_execv(char *progname, char **args) {

	struct vnode *v;
	vaddr_t entrypoint, stackptr;
	int result, i = 0;
	size_t arglen;// size;
	
	int argc;
	char **argv;
	
	while(args[i] != NULL){
		i++;	
	}
	argc = i;

	argv = (char **)kmalloc(sizeof(char*));
	
	/* Copyin arguments from user space */
	for(i = 0;i < argc;i++){
		int len = strlen(args[i])+1;
		argv[i] = (char*)kmalloc(len);
		copyinstr((userptr_t)args[i], argv[i], len, &arglen);
	}	
		
	argv[argc] = NULL;

	/* Open the file. */
	result = vfs_open(progname, O_RDONLY, &v);
	if (result) {
		return result;
	}

	/* Destroy address space to load executable */
	if(curthread->t_vmspace != NULL){
		as_destroy(curthread->t_vmspace);
		curthread->t_vmspace = NULL;
	}

	/* We should be a new thread. */
	assert(curthread->t_vmspace == NULL);

	/* Create a new address space. */
	curthread->t_vmspace = as_create();
	if (curthread->t_vmspace==NULL) {
		vfs_close(v);
		return ENOMEM;
	}

	/* Activate it. */
	as_activate(curthread->t_vmspace);

	/* Load the executable. */
	result = load_elf(v, &entrypoint);
	if (result) {
		/* thread_exit destroys curthread->t_vmspace */
		vfs_close(v);
		return result;
	}

	/* Done with the file now */
	vfs_close(v);

	/* Define the user stack in the address space */
	result = as_define_stack(curthread->t_vmspace, &stackptr);
	if (result) {
		/* thread_exit destroys curthread->t_vmspace */
		return result;
	}
	
	unsigned int para_stack[argc];
	for(i = argc - 1;i >= 0;i--){
		int length = strlen(argv[i]);
		int packed_length = (length % 4);
		
		if(packed_length > 0){
			packed_length = ((int)(length/4) + 1) * 4;
		}
		else if(packed_length == 0){
			packed_length = length;
		}
		
		stackptr = stackptr - (packed_length);
		copyoutstr(argv[i], (userptr_t)stackptr, length, &arglen);
		para_stack[i] = stackptr;
	}

	/* Copy user arguments from kernel buffers into user stack */
	para_stack[argc] = (int)NULL;
	for(i = argc - 1;i >= 0;i--){
		stackptr = stackptr - 4;
		copyout(&para_stack[i], (userptr_t)stackptr, sizeof(para_stack[i]));
	}

	/* Warp to user mode */
	md_usermode(argc /*argc*/, (userptr_t)stackptr /* userspace addr of argv */, stackptr, entrypoint);

	/* md_usermode does not return */
	panic("md_usermode returned\n");
	return EINVAL;
}

