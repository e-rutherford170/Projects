/*
 * Fork the current process and have parent return child's pid
 */

#include <thread.h>
#include <curthread.h>
#include <types.h>
#include <kern/types.h>
#include <machine/types.h>
#include <syscall.h>
#include <machine/pcb.h>
#include <machine/spl.h>
#include <machine/trapframe.h>
#include <kern/callno.h>
#include <lib.h>
#include <kern/errno.h>

int sys_fork(struct trapframe *parent_tf, pid_t *ret) {

	int retval = 0;
	struct trapframe *parent = kmalloc(sizeof(struct trapframe));
	//u_int32_t addr = parent_tf->tf_vaddr;
	struct thread *child = NULL;
	
	if (parent == NULL){
		kfree(parent);
		return ENOMEM;
	}

	int spl;
	spl = splhigh();
	memcpy(parent, parent_tf, sizeof(struct trapframe));
	splx(spl);	

	retval = thread_fork(curthread->t_name, parent, 0, md_forkentry, &child);	
	
	*ret = child->pid;

	return retval;

}
