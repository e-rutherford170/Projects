/*
 * Get process id of current process
 */

#include <types.h>
#include <kern/types.h>
#include <thread.h>
#include <curthread.h>
#include <syscall.h>


struct thread *curthread;

pid_t sys_getpid() {

	pid_t pid = curthread->pid;

	return pid;
	
} 
