/*
 * Exit process
 */

#include <thread.h>
#include <curthread.h>
#include <types.h>
#include <syscall.h>
#include <machine/pcb.h>
#include <machine/spl.h>
#include <machine/trapframe.h>
#include <kern/callno.h>
#include <process.h>
#include <synch.h>

int sys_exit(int code) {

	pid_t pid = curthread->pid;
	struct process *curProcess = get_process(pid);
	
	if(curProcess != NULL){
		lock_acquire(curProcess->exitlock);
		curProcess->exit = 1;
		curProcess->exit_status = code;
		lock_release(curProcess->exitlock); 	
	}

	thread_exit();

	//panic("Should not be here in sys_exit\n");
	
	return 0;
}
