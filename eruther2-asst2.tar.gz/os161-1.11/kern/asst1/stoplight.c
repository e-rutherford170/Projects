/* 
 * stoplight.c
 *
 * 31-1-2003 : GWA : Stub functions created for CS161 Asst1.
 *
 * NB: You can use any synchronization primitives available to solve
 * the stoplight problem in this file.
 */


/*
 * 
 * Includes
 *
 */

#include <types.h>
#include <lib.h>
#include <test.h>
#include <thread.h>
#include <synch.h>

/*
 *
 * Constants
 *
 */

/*
 * Number of vehicles created.
 */

#define NVEHICLES 20

struct lock *resources[3]; // three resources 0->AB, 1->BC, 2->CA
struct lock *routes[3]; // route resource for threads 0->A, 1->B, 2->C
int m = 0; // number of vehicles completed
int route[3]; //counts of vehicles in routes 0->A, 1->B, 2->C
int truck[3]; //counts of trucks in routes
int car[3];   //counts of cars in routes

/*
 *
 * Function Definitions
 *
 */


/*
 * turnleft()
 *
 * Arguments:
 *      unsigned long vehicledirection: the direction from which the car
 *              approaches the intersection.
 *      unsigned long vehiclenumber: the car id number for printing purposes.
 *
 * Returns:
 *      nothing.
 *
 * Notes:
 *      This function should implement making a left turn through the 
 *      intersection from any direction.
 *      Write and comment this function.
 */

static
void
turnleft(unsigned long vehicledirection,
         unsigned long vehiclenumber,
	 unsigned long vehicletype)
{
 	unsigned long num1, num2;
	char src, dest, *resrc1, *resrc2;		
		
	// Set source and dest routes
	if(vehicledirection == 0){
		src = 'A';
		dest = 'C';
	}
	if(vehicledirection == 1){
		src = 'B';
		dest = 'A';
	}
	if(vehicledirection == 2){
		src = 'C';
		dest = 'B';
	}
	
	// get both resources needed to make left
	num1 = vehicledirection;
	num2 = (vehicledirection + 1) % 3;
	
	// get resource name from lock for printing
	resrc1 = (resources[num1])->name;
	resrc2 = (resources[num2])->name;

	lock_acquire(routes[vehicledirection]); // one thread at a time per route

	// this is left from trying to implement a priority but kept reaching deadlocks
	if(vehicletype == 0){
		lock_acquire(resources[num1]);
		
		car[vehicledirection]--;
		route[vehicledirection]--;
		
		// display for first resource
		kprintf("- Intersection1 / Vehicle #: %ld\t/  Vehicle type: %ld  /  Source: %c  /  Dest: %c  /  %s\n", vehiclenumber,vehicletype,src,dest,resrc1);
			
		lock_acquire(resources[num2]);
			
		// display for second resource
		kprintf("- Intersection2 / Vehicle #: %ld\t/  Vehicle type: %ld  /  Source: %c  /  Dest: %c  /  %s\n", vehiclenumber,vehicletype,src,dest,resrc2);

		lock_release(resources[num1]);
			
		// display leave
		kprintf("- Leaving\t/ Vehicle #: %ld\t/  Vehicle type: %ld  /  Source: %c  /  Dest: %c\n", vehiclenumber,vehicletype,src,dest);
				
		lock_release(resources[num2]);	
		m++;
	}

	if(vehicletype == 1){		
		lock_acquire(resources[num1]);			

		truck[vehicledirection]--;
		route[vehicledirection]--;
	
		// display for first resource
		kprintf("- Intersection1 / Vehicle #: %ld\t/  Vehicle type: %ld  /  Source: %c  /  Dest: %c  /  %s\n", vehiclenumber,vehicletype,src,dest,resrc1);
			
		lock_acquire(resources[num2]);
			
		// display for second resource
		kprintf("- Intersection2 / Vehicle #: %ld\t/  Vehicle type: %ld  /  Source: %c  /  Dest: %c  /  %s\n", vehiclenumber,vehicletype,src,dest,resrc2);

		lock_release(resources[num1]);
			
		// display leave
		kprintf("- Leaving\t/ Vehicle #: %ld\t/  Vehicle type: %ld  /  Source: %c  /  Dest: %c\n", vehiclenumber,vehicletype,src,dest);
				
		lock_release(resources[num2]);	
		m++;	
	}

	lock_release(routes[vehicledirection]);      
	
}


/*
 * turnright()
 *
 * Arguments:
 *      unsigned long vehicledirection: the direction from which the vehicle
 *              approaches the intersection.
 *      unsigned long vehiclenumber: the car id number for printing purposes.
 *
 * Returns:
 *      nothing.
 *
 * Notes:
 *      This function should implement making a right turn through the 
 *      intersection from any direction.
 *      Write and comment this function.
 */

static
void
turnright(unsigned long vehicledirection,
          unsigned long vehiclenumber,
	  unsigned long vehicletype)
{
        
	char src, dest, *resrc;

	// set source and dest chars
	if(vehicledirection == 0){
		src = 'A';
		dest = 'B';
	}
	if(vehicledirection == 1){
		src = 'B';
		dest = 'C';
	}
	if(vehicledirection == 2){
		src = 'C';
		dest = 'A';
	}	

	// get resource name from lock for printing
	resrc = (resources[vehicledirection])->name;

	lock_acquire(routes[vehicledirection]); // one thread at a time per route

	// this is left from trying to implement a priority but kept reaching deadlocks
	if(vehicletype == 0){

		lock_acquire(resources[vehicledirection]);

		car[vehicledirection]--;
		route[vehicledirection]--;

		// display using resource in intersection
		kprintf("- Intersection\t/ Vehicle #: %ld\t/  Vehicle type: %ld  /  Source: %c  /  Dest: %c  /  %s\n", vehiclenumber,vehicletype,src,dest,resrc);

		// display leaving intersection
		kprintf("- Leaving\t/ Vehicle #: %ld\t/  Vehicle type: %ld  /  Source: %c  /  Dest: %c\n", vehiclenumber,vehicletype,src,dest);
		
		lock_release(resources[vehicledirection]);		
		m++;
	}	

	if(vehicletype == 1){			
		
		lock_acquire(resources[vehicledirection]);
			
		truck[vehicledirection]--;
		route[vehicledirection]--;
	
		// display using resource in intersection
		kprintf("- Intersection\t/ Vehicle #: %ld\t/  Vehicle type: %ld  /  Source: %c  /  Dest: %c  /  %s\n", vehiclenumber,vehicletype,src,dest,resrc);
	
		// display leaving intersection
		kprintf("- Leaving\t/ Vehicle #: %ld\t/  Vehicle type: %ld  /  Source: %c  /  Dest: %c\n", vehiclenumber,vehicletype,src,dest);

		lock_release(resources[vehicledirection]);
		m++;
	}	

	lock_release(routes[vehicledirection]);

}


/*
 * approachintersection()
 *
 * Arguments: 
 *      void * unusedpointer: currently unused.
 *      unsigned long vehiclenumber: holds vehicle id number.
 *
 * Returns:
 *      nothing.
 *
 * Notes:
 *      Change this function as necessary to implement your solution. These
 *      threads are created by createvehicles().  Each one must choose a direction
 *      randomly, approach the intersection, choose a turn randomly, and then
 *      complete that turn.  The code to choose a direction randomly is
 *      provided, the rest is left to you to implement.  Making a turn
 *      or going straight should be done by calling one of the functions
 *      above.
 */
 
static
void
approachintersection(void * unusedpointer,
                     unsigned long vehiclenumber)
{
        int vehicledirection, turndirection, vehicletype;
	char src, dest;	
 
	/*
         * Avoid unused variable and function warnings.
         */

        (void) unusedpointer;


        /*
         * vehicledirection is set randomly.
         */
	
        vehicledirection = random() % 3;
	turndirection = random() % 2;
	vehicletype = random() % 2;	


	// Switch for a left or right turn (0 = right / 1 = left)
	switch(turndirection){
		case 0:	
			if(vehicledirection == 0){
				src = 'A';
				dest = 'B';
			}
			if(vehicledirection == 1){
				src = 'B';
				dest = 'C';
			}
			if(vehicledirection == 2){
				src = 'C';
				dest = 'A';
			}
			
			route[vehicledirection]++;

			if(vehicletype == 0){
				car[vehicledirection]++;
			}
			if(vehicletype == 1){
				truck[vehicledirection]++;
			}

			kprintf("- Approaching\t/ Vehicle #: %ld\t/  Vehicle type: %d  /  Source: %c  /  Dest: %c  /  Turning: Right\n", vehiclenumber,vehicletype,src,dest);
			turnright(vehicledirection,vehiclenumber,vehicletype);
			
			break;
		case 1: 
			if(vehicledirection == 0){
				src = 'A';
				dest = 'C';
			}
			if(vehicledirection == 1){
				src = 'B';
				dest = 'A';
			}
			if(vehicledirection == 2){
				src = 'C';
				dest = 'B';
			}

			route[vehicledirection]++;
		
			if(vehicletype == 0){
				car[vehicledirection]++;
			}
			if(vehicletype == 1){
				truck[vehicledirection]++;	
			}
		
			kprintf("- Approaching\t/ Vehicle #: %ld\t/  Vehicle type: %d  /  Source: %c  /  Dest: %c  /  Turning: Left\n", vehiclenumber,vehicletype,src,dest);
			turnleft(vehicledirection,vehiclenumber,vehicletype);
	
			break;
	}	
		
}


/*
 * createvehicles()
 *
 * Arguments:
 *      int nargs: unused.
 *      char ** args: unused.
 *
 * Returns:
 *      0 on success.
 *
 * Notes:
 *      Driver code to start up the approachintersection() threads.  You are
 *      free to modiy this code as necessary for your solution.
 */

int
createvehicles(int nargs,
           char ** args)
{
        int index, error;

	resources[0] = lock_create("Resource: AB");
	resources[1] = lock_create("Resource: BC");
	resources[2] = lock_create("Resource: CA");

	route[0] = 0;
	route[1] = 0;
	route[2] = 0;
	
	routes[0] = lock_create("Route A Trucks");
	routes[1] = lock_create("Route B Trucks");
	routes[2] = lock_create("Route C Trucks");

        /*
         * Avoid unused variable warnings.
         */
	
        (void) nargs;
        (void) args;

        /*
         * Start NVEHICLES approachintersection() threads.
         */
	
	if(resources[0] == NULL || resources[1] == NULL || resources[2] == NULL){
		panic("Stoplight init failure in lock creation");
	}

        for (index = 0; index < NVEHICLES; index++) {

                error = thread_fork("approachintersection thread",
                                    NULL,
                                    index,
                                    approachintersection,
                                    NULL
                                    );

                /*
                 * panic() on error.
                 */

                if (error) {
                        
                        panic("approachintersection: thread_fork failed: %s\n",
                              strerror(error)
                              );
                }
        }
	// wait for 20 vehicles to leave then pass
	while(m<(NVEHICLES));
	kprintf("\nSuccess! All %d vehicles passed the intersection.\n\n",(m));
	m = 0;
	
	// destroy all created locks
	lock_destroy(resources[0]);
	lock_destroy(resources[1]);
	lock_destroy(resources[2]);
	
	lock_destroy(routes[0]);
	lock_destroy(routes[1]);
	lock_destroy(routes[2]);
		
        return 0;
}
