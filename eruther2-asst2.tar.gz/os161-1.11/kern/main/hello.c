
void hello(void);

void hello()
{
	kprintf("Hello World\n");
}
