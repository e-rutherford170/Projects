#ifndef _PROCESS_H_
#define _PROCESS_H_

/*
 * Definition for process
 */

#include <kern/types.h>
#include <types.h>
#include <machine/types.h>
#include <thread.h>


#define MAX_PROCESSES 5000

/*
 * Process structure
 */
struct process {
	pid_t pid;
	pid_t pPid;
	struct lock *exitlock;
	int exit;
	int exit_status;
	struct thread *self;
};

/*
 * Process table structure (Linked list)
 */
//struct process_table {
//	pid_t pid; 		   // In process table to search for process using pid then extract thread
//	struct process *process;   // Process at index in table
//	struct process_table *next;// Linked list implementation to build up process table
//};

void process_bootstrap(void);
pid_t pid_allocate(struct thread *th);
int p_exists(pid_t pid);
int remove_process(pid_t pid);
struct process* get_process(pid_t pid);

#endif 
