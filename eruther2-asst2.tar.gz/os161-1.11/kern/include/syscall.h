#ifndef _SYSCALL_H_
#define _SYSCALL_H_

#include <kern/types.h>
#include <types.h>
#include <machine/types.h>

/*
 * Prototypes for IN-KERNEL entry points for system call implementations.
 */

int sys_reboot(int code);
pid_t sys_getpid();
pid_t sys_getppid();
int sys_execv(char *progam, char **args);
int sys_fork(struct trapframe *parent_tf, pid_t *ret);
int sys_waitpid(pid_t pid, userptr_t status, int options, int *ret);
int sys_exit(int code);

#endif /* _SYSCALL_H_ */
