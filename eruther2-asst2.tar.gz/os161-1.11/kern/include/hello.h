void hello(void);void hello(void);
